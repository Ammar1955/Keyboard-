package com.stepup.arfakeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

/**
 * نشاط بسيط يفتح تلقائياً عند تشغيل التطبيق، ويوجه المستخدم مباشرة
 * لصفحة "اللغات والإدخال" في إعدادات أندرويد لتفعيل الكيبورد،
 * ثم يفتح منتقي لوحات المفاتيح لاختيارها فوراً.
 */
class SetupActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Toast.makeText(
            this,
            "الخطوة 1: فعّل الكيبورد من القائمة القادمة",
            Toast.LENGTH_LONG
        ).show()

        // يفتح صفحة إعدادات لوحات المفاتيح في النظام
        startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))

        finish()
    }
}
