package com.stepup.arfakeyboard

import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/**
 * كيبورد يدمج الحروف العربية والفارسية بلوحة واحدة، مع إبقاء الأرقام
 * بالشكل الإنجليزي (0-9) دائماً بدل الأرقام الهندية/الفارسية.
 */
class ArFaInputMethodService : InputMethodService() {

    // حالة اللوحة الحالية: حروف أو رموز/أرقام
    private var symbolsMode = false
    private var capsOn = false

    // صف الأرقام - يبقى دائماً إنجليزي بحسب طلبك
    private val numberRow = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")

    // الحروف العربية + الحروف الفارسية المضافة (چ پ ژ گ) مدمجة بلوحة واحدة
    private val row2 = listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ")
    private val row3 = listOf("ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ")
    private val row4 = listOf("ظ", "ط", "ژ", "ز", "ر", "ذ", "د", "پ", "و", ".", "،")

    // وضع الرموز/الأرقام
    private val symRow2 = listOf("!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_")
    private val symRow3 = listOf("/", ":", ";", "\"", "'", "؟", "=", "+", "\\", "|", "~")
    private val symRow4 = listOf("[", "]", "{", "}", "٪", ",", "؛", "?", "<", ">", "`")

    private lateinit var row1Layout: LinearLayout
    private lateinit var row2Layout: LinearLayout
    private lateinit var row3Layout: LinearLayout
    private lateinit var row4Layout: LinearLayout
    private lateinit var row5Layout: LinearLayout

    override fun onCreateInputView(): View {
        val keyboardView = LayoutInflater.from(this).inflate(R.layout.keyboard_view, null)

        row1Layout = keyboardView.findViewById(R.id.row1)
        row2Layout = keyboardView.findViewById(R.id.row2)
        row3Layout = keyboardView.findViewById(R.id.row3)
        row4Layout = keyboardView.findViewById(R.id.row4)
        row5Layout = keyboardView.findViewById(R.id.row5)

        buildKeyboard()
        return keyboardView
    }

    private fun buildKeyboard() {
        row1Layout.removeAllViews()
        row2Layout.removeAllViews()
        row3Layout.removeAllViews()
        row4Layout.removeAllViews()
        row5Layout.removeAllViews()

        // صف الأرقام يبقى إنجليزي دائماً بغض النظر عن الوضع
        numberRow.forEach { addKey(row1Layout, it, weight = 1f) }

        if (symbolsMode) {
            symRow2.forEach { addKey(row2Layout, it, weight = 1f) }
            symRow3.forEach { addKey(row3Layout, it, weight = 1f) }
            symRow4.forEach { addKey(row4Layout, it, weight = 1f) }
        } else {
            row2.forEach { addKey(row2Layout, applyCase(it), weight = 1f) }
            row3.forEach { addKey(row3Layout, applyCase(it), weight = 1f) }
            row4.forEach { addKey(row4Layout, applyCase(it), weight = 1f) }
        }

        buildBottomRow()
    }

    private fun applyCase(s: String): String = s // العربية والفارسية لا تحتوي حالة أحرف كبيرة/صغيرة

    private fun buildBottomRow() {
        // زر 123/ABC للتبديل بين الحروف والرموز
        val switchSymbolsBtn = createButton(if (symbolsMode) "ابج" else "١٢٣", special = true)
        switchSymbolsBtn.setOnClickListener {
            symbolsMode = !symbolsMode
            buildKeyboard()
        }
        row5Layout.addView(switchSymbolsBtn, rowParams(1.3f))

        // زر تبديل لوحة النظام (لو المستخدم يريد يرجع للإنجليزي مثلاً)
        val globeBtn = createButton("🌐", special = true)
        globeBtn.setOnClickListener {
            switchToNextInputMethod()
        }
        row5Layout.addView(globeBtn, rowParams(1f))

        // زر المسافة
        val spaceBtn = createButton("مسافة", special = true)
        spaceBtn.setOnClickListener {
            currentInputConnection?.commitText(" ", 1)
        }
        row5Layout.addView(spaceBtn, rowParams(4f))

        // زر الحذف
        val deleteBtn = createButton("⌫", special = true)
        deleteBtn.setOnClickListener {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
        row5Layout.addView(deleteBtn, rowParams(1.3f))

        // زر الإدخال/سطر جديد
        val enterBtn = createButton("↵", special = true)
        enterBtn.setOnClickListener {
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)
            )
        }
        row5Layout.addView(enterBtn, rowParams(1.3f))
    }

    private fun switchToNextInputMethod() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            requestShowSelf(0)
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showInputMethodPicker()
        } else {
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showInputMethodPicker()
        }
    }

    private fun addKey(parent: LinearLayout, label: String, weight: Float) {
        val btn = createButton(label, special = false)
        btn.setOnClickListener {
            currentInputConnection?.commitText(label, 1)
        }
        parent.addView(btn, rowParams(weight))
    }

    private fun createButton(label: String, special: Boolean): Button {
        val btn = Button(this)
        btn.text = label
        btn.textSize = if (special) 14f else 18f
        btn.setTextColor(resources.getColor(R.color.key_text, theme))
        btn.background = resources.getDrawable(
            if (special) R.drawable.special_key_bg_selector else R.drawable.key_bg_selector,
            theme
        )
        btn.isAllCaps = false
        btn.setPadding(2, 20, 2, 20)
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(2, 2, 2, 2)
        btn.layoutParams = lp
        return btn
    }

    private fun rowParams(weight: Float): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
        lp.setMargins(2, 2, 2, 2)
        return lp
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        symbolsMode = false
    }
}
